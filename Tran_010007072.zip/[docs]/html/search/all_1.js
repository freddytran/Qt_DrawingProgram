var searchData=
[
  ['bordercolor',['borderColor',['../class_tools.html#af7de157c4f6575664512accd32d93a43',1,'Tools']]]
];
