var searchData=
[
  ['xkoord',['xkoord',['../class_object_options.html#a738e07899e3eff5aeb2f998bf527b804',1,'ObjectOptions']]]
];
