var searchData=
[
  ['ykoord',['ykoord',['../class_object_options.html#a3306979371a1f706724d2e5a449d3f72',1,'ObjectOptions']]]
];
