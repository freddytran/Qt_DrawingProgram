var searchData=
[
  ['name',['name',['../class_graphics_object.html#ac5591ff2b8009451c593d1197ce7a162',1,'GraphicsObject']]],
  ['none_5factive',['NONE_ACTIVE',['../class_tools.html#a2847c269682818722541d9002fdf0824a39a562c65ff6fde1589fd79d63b16b31',1,'Tools']]]
];
