var searchData=
[
  ['paintevent',['paintEvent',['../class_color_button.html#ae7b2847c9974fb52f80d54dafc7a0f00',1,'ColorButton']]],
  ['polygon',['Polygon',['../class_polygon.html',1,'Polygon'],['../class_polygon.html#acca8d3957dfbd44bb27c4519d2bfeb83',1,'Polygon::Polygon(QObject *parent=nullptr)'],['../class_polygon.html#a848d8c9194ace0906ae31bb9c26e3829',1,'Polygon::Polygon(QPolygon polygon, QColor pen, QColor brush)'],['../class_tools.html#ab031688a77e89a80ce8b5db7014684a3a883ff4bc5dc9f42f40f091328bcf1907',1,'Tools::POLYGON()']]],
  ['polygon_2ecpp',['polygon.cpp',['../polygon_8cpp.html',1,'']]],
  ['polygon_2eh',['polygon.h',['../polygon_8h.html',1,'']]]
];
