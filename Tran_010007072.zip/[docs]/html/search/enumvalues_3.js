var searchData=
[
  ['none_5factive',['NONE_ACTIVE',['../class_tools.html#a2847c269682818722541d9002fdf0824a39a562c65ff6fde1589fd79d63b16b31',1,'Tools']]]
];
