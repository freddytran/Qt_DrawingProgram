var searchData=
[
  ['polygon',['POLYGON',['../class_tools.html#ab031688a77e89a80ce8b5db7014684a3a883ff4bc5dc9f42f40f091328bcf1907',1,'Tools']]]
];
