var searchData=
[
  ['circle',['Circle',['../class_circle.html#a9851632042d96e4e534bebbec65e92c3',1,'Circle::Circle(QObject *parent=nullptr)'],['../class_circle.html#a4e15e9f73da6961e60965dd2fdb0d19a',1,'Circle::Circle(qreal xkoord, qreal ykoord, qreal width, qreal height, QColor fill, QColor border)']]],
  ['color',['color',['../class_color_button.html#a7583a20c9a126ba93e344ea728c19954',1,'ColorButton']]],
  ['colorbutton',['ColorButton',['../class_color_button.html#a128b21900f22efdc9d71d0bffa0b64f8',1,'ColorButton::ColorButton(QWidget *parent=0)'],['../class_color_button.html#a16f9cc31b3476fc5cb900e3692d4f49c',1,'ColorButton::ColorButton(QColor color, QWidget *parent=0)']]],
  ['colorselector',['ColorSelector',['../class_color_selector.html#aa8669eb9e5da7ca151ef84fba84a5f34',1,'ColorSelector']]]
];
