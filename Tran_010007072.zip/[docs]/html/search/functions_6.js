var searchData=
[
  ['name',['name',['../class_graphics_object.html#ac5591ff2b8009451c593d1197ce7a162',1,'GraphicsObject']]]
];
