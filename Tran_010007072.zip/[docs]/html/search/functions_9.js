var searchData=
[
  ['recievefocuseditem',['recieveFocusedItem',['../class_main_window.html#aee13312aef8f1fc2a4c7ff2f8837234c',1,'MainWindow']]],
  ['recievemouseclickedposition',['recieveMouseClickedPosition',['../class_main_window.html#a3ea2675e6bd470873d7569db47a5bd2a',1,'MainWindow']]],
  ['recievemouseposition',['recieveMousePosition',['../class_main_window.html#a965877b0ba4c3f18035232a9eb7b98e0',1,'MainWindow']]],
  ['rectangle',['Rectangle',['../class_rectangle.html#a3a431eeb9b63f2108f171416b205f302',1,'Rectangle::Rectangle(QObject *parent=nullptr)'],['../class_rectangle.html#a07eb215e78b898b77cb843ceb497b46a',1,'Rectangle::Rectangle(qreal xkoord, qreal ykoord, qreal width, qreal height, QColor fill, QColor border)']]]
];
