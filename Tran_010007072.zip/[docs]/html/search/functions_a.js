var searchData=
[
  ['sendmouseclickedposition',['sendMouseClickedPosition',['../class_graphics_scene.html#ac781d598feae85b0a0c6a90c30f914bd',1,'GraphicsScene']]],
  ['sendmouseposition',['sendMousePosition',['../class_graphics_scene.html#aee2d967bd98adf009edf0ecd08cec189',1,'GraphicsScene']]],
  ['setbordercolor',['setBorderColor',['../class_tools.html#a94304e05407643ce69f20ba93538d3d5',1,'Tools']]],
  ['setcolor',['setColor',['../class_color_button.html#ad0d3747c9ceb3ed57d3f513f42fd4cf2',1,'ColorButton']]],
  ['setdrawtool',['setDrawTool',['../class_tools.html#aa53c7186fb6cd6104ff42014b6f44f93',1,'Tools']]],
  ['setfillcolor',['setFillColor',['../class_tools.html#a4912994771a4424b9aec1a7b16d31176',1,'Tools']]],
  ['setheight',['setHeight',['../class_object_options.html#a7e490c997a49ddd45317598dc851f473',1,'ObjectOptions']]],
  ['setname',['setName',['../class_graphics_object.html#a1b0c7c7f87e86833a9a23ab1a2b6f685',1,'GraphicsObject']]],
  ['setoptiontool',['setOptionTool',['../class_tools.html#af69d4aa896ef3e1b06ce65e5df53f060',1,'Tools']]],
  ['setstate',['setState',['../class_tools.html#abdf68db9740ba504701fe00d97a031e2',1,'Tools']]],
  ['setwidth',['setWidth',['../class_object_options.html#a33cd9c2ae781069d22babab1ac346af9',1,'ObjectOptions']]],
  ['setxkoord',['setXkoord',['../class_object_options.html#acdb5c1b9952fda67ac8393055acfd756',1,'ObjectOptions']]],
  ['setykoord',['setYkoord',['../class_object_options.html#a32b59030cadbd75a09ed0056df03d342',1,'ObjectOptions']]]
];
