var searchData=
[
  ['status',['status',['../class_tools.html#a9ee6b69697a16133db9d1f24346cd838',1,'Tools']]]
];
