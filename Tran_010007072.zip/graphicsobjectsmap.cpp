#include "graphicsobjectsmap.h"

/**
 * @brief GraphicsObjectsMap::GraphicsObjectsMap. Liste in der die Objekte gespeichert werden.
 */
GraphicsObjectsMap::GraphicsObjectsMap()
{

}
